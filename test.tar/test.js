console.log('test');
var a =require('./print');
a.p();