var a = require('./print');
console.log("app");
a.p();
require('./test');
var http = require('http'),
    server = http.createServer(),
    port = process.env.PORT || 0;
server.listen(port, function () {
    console.log(process.cwd());
    if(Math.random()>0.8){
        throw new Error("die");
    }
});