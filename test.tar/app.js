   console.log(process.cwd());
console.log("app");
var http = require('http'),
    server = http.createServer(),
    port = process.env.PORT || 0;
   console.log(process.cwd());
console.log('(',port);
server.listen(port, function () {
    console.log(process.cwd());
});
