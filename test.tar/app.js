var a = require('./print');
console.log("app");
a.p();
require('./test');
var http = require('http'),
    server = http.createServer(),
    port = process.env.PORT || 0;
   console.log(process.cwd());
server.listen(port, function () {
    console.log(process.cwd());
});
