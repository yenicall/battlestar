console.log("totosqsqs");
var i = 0;
exports.p = function () {
    console.log('i', i);
    i++;
};